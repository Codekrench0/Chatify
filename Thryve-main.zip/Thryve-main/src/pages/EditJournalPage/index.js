import EditJournalPage from "./EditJournalPage.jsx";

export default EditJournalPage;