import LandingPage from "./LandingPage.jsx";

export default LandingPage;