import CalendarPage from './CalendarPage';

export default CalendarPage;