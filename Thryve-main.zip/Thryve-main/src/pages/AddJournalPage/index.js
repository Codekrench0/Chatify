import AddJournalPage from './AddJournalPage.jsx';

export default AddJournalPage;