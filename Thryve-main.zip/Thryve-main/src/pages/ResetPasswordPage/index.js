import ResetPasswordPage from './ResetPasswordPage.jsx';

export default ResetPasswordPage;