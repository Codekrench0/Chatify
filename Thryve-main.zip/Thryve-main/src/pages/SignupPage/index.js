import SignupPage from './SignupPage.jsx';

export default SignupPage;