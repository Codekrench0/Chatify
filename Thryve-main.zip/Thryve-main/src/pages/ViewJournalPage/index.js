import ViewJournalPage from "./ViewJournalPage.jsx";

export default ViewJournalPage;
