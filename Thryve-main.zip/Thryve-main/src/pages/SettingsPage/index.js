import SettingsPage from './SettingsPage.jsx';

export default SettingsPage;