import LoginPage from './LoginPage.jsx';

export default LoginPage;