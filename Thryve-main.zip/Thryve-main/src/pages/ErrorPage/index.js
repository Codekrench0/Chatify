import ErrorPage from "./ErrorPage.jsx";

export default ErrorPage;