import UnverifiedEmail from '././UnverifiedEmail.jsx';

export default UnverifiedEmail;