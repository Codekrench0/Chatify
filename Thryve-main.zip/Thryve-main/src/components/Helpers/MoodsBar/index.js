import MoodsBar from './MoodsBar.jsx';

export default MoodsBar;