import Loader from './Loader.jsx';

export default Loader;