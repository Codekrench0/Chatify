import JournalActionTab from './JournalActionTab';

export default JournalActionTab;